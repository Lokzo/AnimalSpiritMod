﻿using System;
using System.Text;
using UnityEngine;
using Il2CppSystem.Collections.Generic;

namespace AnimalSpiritMod
{
	public class SeagullSkill
	{
		public static PlayerControl getClosestPlayer(PlayerControl player)
		{
			PlayerControl target = null;
			if (!ShipStatus.Instance)
			{
				return null;
			}
			bool start = true;
			Vector2 vector;
			float magnitude = float.MaxValue;
			Vector2 truePosition = player.GetTruePosition();
			List<GameData.PlayerInfo> allPlayers = GameData.Instance.AllPlayers;
			for (int i = 0; i < allPlayers.Count; i++)
			{
				GameData.PlayerInfo playerInfo = allPlayers[i];
				if (!playerInfo.Disconnected && playerInfo.PlayerId != player.PlayerId && !playerInfo.IsDead)
				{
					PlayerControl @object = playerInfo.Object;
					if (@object)
					{
						vector = @object.GetTruePosition() - truePosition;
						if (start)
						{
							target = @object;
							start = false;
							magnitude = vector.magnitude;
						}
						else if(vector.magnitude <= magnitude)
                        {
							target = @object;
							magnitude = vector.magnitude;
						}
					}
				}
			}

			return target;
		}
	}
}

