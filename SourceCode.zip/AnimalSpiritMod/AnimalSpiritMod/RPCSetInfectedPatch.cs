﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Hazel;
using UnhollowerBaseLib;
using System.Linq;
using Reactor;
using UnityEngine;

namespace AnimalSpiritMod
{
	[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.RpcSetInfected))]
	public static class RpcSetInfectedPatch
	{
        public static void Postfix([HarmonyArgument(0)] Il2CppReferenceArray<GameData.PlayerInfo> playerInfo)
        {
            List<PlayerControl> playersList = PlayerControl.AllPlayerControls.ToArray().ToList();
            PlayerControl player = PlayerControl.LocalPlayer;

            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Snoop = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Snoop.PlayerId;
                playersList.Remove(Variables.Snoop);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetSnoop, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Cheetah = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Cheetah.PlayerId;
                playersList.Remove(Variables.Cheetah);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetCaptain, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Wolf = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Wolf.PlayerId;
                playersList.Remove(Variables.Wolf);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetHacker, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Chameleon = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Chameleon.PlayerId;
                playersList.Remove(Variables.Chameleon);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetGhost, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                
            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Monkey = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Monkey.PlayerId;
                playersList.Remove(Variables.Monkey);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetMonkey, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);

            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Seagull = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Seagull.PlayerId;
                playersList.Remove(Variables.Seagull);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetSeagull, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);

            }
            if (playersList != null && playersList.Count > 0)
            {
                System.Random random = new System.Random();
                Variables.Snake = playersList[random.Next(0, playersList.Count)];
                byte playerId = Variables.Snake.PlayerId;
                playersList.Remove(Variables.Snake);
                MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(PlayerControl.LocalPlayer.NetId, (byte)CustomRPC.SetSnake, SendOption.None, -1);
                messageWriter.Write(playerId);
                AmongUsClient.Instance.FinishRpcImmediately(messageWriter);

            }

        }
    
	}
    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.SetInfected))]
    public class SetInfetedpatch
    {

        private static CooldownButton ChameleonButton;
        private static CooldownButton CheetahButton;
        private static CooldownButton WolfButton;
        private static CooldownButton SnakeButton;
        private static CooldownButton SeagullButton;

        public static void Postfix()
        {
            PlayerControl player = PlayerControl.LocalPlayer;
            Variables.baseSpeed = player.MyPhysics.Speed;
            Variables.target = player;
            
                
            ChameleonButton = new CooldownButton(
                () =>
                {
                    Color translucent = new Color(0f, 0f, 0f, 0.1f);
                    player.myRend.material.SetColor("_BackColor", translucent);
                    player.myRend.material.SetColor("_BodyColor", translucent);
                    MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.SetVarInvisibleTrue, SendOption.None, -1);
                    messageWriter.Write(player.PlayerId);
                    AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                },
                30f,
                Properties.Resources.Sphere,
                new Vector2(0.125f, 0.125f),
                () =>
                {
                    return !player.Data.IsDead && Variables.IsChameleon(player.PlayerId);// && (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started || AmongUsClient.Instance.GameMode == GameModes.FreePlay);
                },
                HudManager.Instance,
                5f,
                () =>
                {
                    player.myRend.material.SetColor("_BodyColor", Palette.PlayerColors[player.Data.ColorId]);
                    player.myRend.material.SetColor("_BackColor", Palette.PlayerColors[player.Data.ColorId]);
                    MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.SetVarInvisibleFalse, SendOption.None, -1);
                    messageWriter.Write(player.PlayerId);
                    AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                });

            CheetahButton = new CooldownButton(
                () =>
                {
                    player.MyPhysics.Speed *= 2;
                },
                15f,
                Properties.Resources.Sphere,
                new Vector2(0.125f, 0.125f),
                () =>
                {
                    return !player.Data.IsDead && Variables.IsCheetah(player.PlayerId);// && (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started || AmongUsClient.Instance.GameMode == GameModes.FreePlay);
                },
                HudManager.Instance,
                5f,
                () =>
                {
                    player.MyPhysics.Speed /= 2;
                });

            WolfButton = new CooldownButton(
                () =>
                {
                    Variables.WolfBaseName = player.Data.PlayerName;
                    Variables.WolfBaseSkin = player.Data.SkinId;
                    Variables.WolfBasePet = player.Data.PetId;
                    Variables.WolfBaseHat = player.Data.HatId;
                    Variables.WolfBaseColor = player.Data.ColorId;
                    PlayerControl target = WolfSkill.getClosestPlayer(player);
                    player.SetName(target.Data.PlayerName);
                    player.SetSkin(target.Data.SkinId);
                    player.SetPet(target.Data.PetId);
                    player.SetHat(target.Data.HatId, 1);
                    player.SetColor(target.Data.ColorId);
                    MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.WolfSkill, SendOption.None, -1);
                    messageWriter.Write(player.PlayerId);
                    AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                },
                30f,
                Properties.Resources.Sphere,
                new Vector2(0.125f, 0.125f),
                () =>
                {
                    return !player.Data.IsDead && Variables.IsWolf(player.PlayerId);// && (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started || AmongUsClient.Instance.GameMode == GameModes.FreePlay);
                },
                HudManager.Instance,
                10f,
                () =>
                {
                    player.SetName(Variables.WolfBaseName);
                    player.SetSkin(Variables.WolfBaseSkin);
                    player.SetPet(Variables.WolfBasePet);
                    player.SetHat(Variables.WolfBaseHat, 1);
                    player.SetColor(Variables.WolfBaseColor);
                    MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.WolfSkillReset, SendOption.None, -1);
                    messageWriter.Write(player.PlayerId);
                    AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                });

            SnakeButton = new CooldownButton(
                () =>
                {
                    SoundManager.Instance.PlaySound(player.KillSfx, false, 0.8f);
                    MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.SnakeSkill, SendOption.None, -1);
                    messageWriter.Write(player.PlayerId);
                    AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
                },
                5f,
                Properties.Resources.Sphere,
                new Vector2(0.125f, 0.125f),
                () =>
                {
                    return !player.Data.IsDead && Variables.IsSnake(player.PlayerId);// && (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started || AmongUsClient.Instance.GameMode == GameModes.FreePlay);
                },
                HudManager.Instance);

            SeagullButton = new CooldownButton(
                () =>
                {
                    if (Variables.target == PlayerControl.LocalPlayer)
                        Variables.target = SeagullSkill.getClosestPlayer(player);
                    else
                        Variables.target = PlayerControl.LocalPlayer;
                    
                },
                0f,
                Properties.Resources.Sphere,
                new Vector2(0.125f, 0.125f),
                () =>
                {
                    return !player.Data.IsDead && Variables.IsSeagull(player.PlayerId);// && (AmongUsClient.Instance.GameState == InnerNetClient.GameStates.Started || AmongUsClient.Instance.GameMode == GameModes.FreePlay);
                },
                HudManager.Instance);
        }
    }



}
