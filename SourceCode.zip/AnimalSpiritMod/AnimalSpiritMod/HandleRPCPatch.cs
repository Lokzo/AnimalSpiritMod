﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Hazel;
using UnhollowerBaseLib;
using UnityEngine;
using System.Linq;
using Reactor;

namespace AnimalSpiritMod
{
	[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.HandleRpc))]
	class HandleRPCPatch
	{
		public static bool Prefix([HarmonyArgument(0)] byte by, [HarmonyArgument(1)] MessageReader mr)
		{
            if (by == (byte)CustomRPC.SetSnoop)
            {
                Variables.Snoop = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Snoop = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetGhost)
            {
                Variables.Chameleon = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Chameleon = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetCaptain)
            {
                Variables.Cheetah = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Cheetah = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetHacker)
            {
                Variables.Wolf = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Wolf = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetMonkey)
            {
                Variables.Monkey = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Monkey = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetSeagull)
            {
                Variables.Seagull = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Seagull = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.SetSnake)
            {
                Variables.Snake = null;
                byte readByte = mr.ReadByte();
                foreach (PlayerControl player in PlayerControl.AllPlayerControls)
                {
                    if (player.PlayerId == readByte)
                    {
                        Variables.Snake = player;
                    }
                }

                return false;
            }
            if (by == (byte)CustomRPC.Invisible)
            {
                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    if (Variables.IsChameleon(p.PlayerId) && Variables.isInvisible)
                    {
                        p.Visible = false;
                    }
                    else if(!p.Data.IsDead)
                    {
                        p.Visible = true;
                    }
                    if(p.inVent)
                    {
                        p.Visible = false;
                    }
                }
                return false;
            }
            if (by == (byte)CustomRPC.SetVarInvisibleTrue)
            {
                Variables.isInvisible = true;
                return false;
            }
            if (by == (byte)CustomRPC.SetVarInvisibleFalse)
            {
                Variables.isInvisible = false;
                return false;
            }
            if (by == (byte)CustomRPC.WolfSkill)
            {
                PlayerControl player;
                PlayerControl target;
                
                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    if (Variables.IsWolf(p.PlayerId))
                    {
                        Variables.WolfBaseName = p.Data.PlayerName;
                        Variables.WolfBaseSkin = p.Data.SkinId;
                        Variables.WolfBasePet = p.Data.PetId;
                        Variables.WolfBaseHat = p.Data.HatId;
                        Variables.WolfBaseColor = p.Data.ColorId;
                        player = Variables.Wolf;
                        target = WolfSkill.getClosestPlayer(player);
                        p.SetName(target.Data.PlayerName);
                        p.SetSkin(target.Data.SkinId);
                        p.SetPet(target.Data.PetId);
                        p.SetHat(target.Data.HatId, 1);
                        p.SetColor(target.Data.ColorId);
                    }
                }
                return false;
            }
            if (by == (byte)CustomRPC.WolfSkillReset)
            {

                foreach (PlayerControl p in PlayerControl.AllPlayerControls)
                {
                    if (Variables.IsWolf(p.PlayerId))
                    {
                        p.SetName(Variables.WolfBaseName);
                        p.SetSkin(Variables.WolfBaseSkin);
                        p.SetPet(Variables.WolfBasePet);
                        p.SetHat(Variables.WolfBaseHat, 1);
                        p.SetColor(Variables.WolfBaseColor);
                    }
                }
                return false;
            }
            if (by == (byte)CustomRPC.SnakeSkill)
            {
                PlayerControl player = PlayerControl.LocalPlayer;
                SoundManager.Instance.PlaySound(player.KillSfx, false, 0.8f);
                return false;
            }

            return true;
		}

	}
}
