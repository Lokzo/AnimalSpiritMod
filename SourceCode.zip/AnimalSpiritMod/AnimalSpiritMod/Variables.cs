﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Hazel;
using UnhollowerBaseLib;
using System.Linq;
using Reactor;
using UnityEngine;
using System.IO;
using System.Reflection;
using Reactor.Extensions;
using System.Collections;
using Reactor.Unstrip;

namespace AnimalSpiritMod
{
    public static class Variables
    {
        //Roles
        public static PlayerControl Snoop;
        public static PlayerControl Chameleon;
        public static PlayerControl Cheetah;
        public static PlayerControl Wolf;
        public static PlayerControl Snake;
        public static PlayerControl Seagull;
        public static PlayerControl Monkey;

        //Colors
        public static Color Snoop_c = Palette.PlayerColors[3];
        public static Color Chameleon_c = Palette.PlayerColors[11];
        public static Color Cheetah_c = Palette.PlayerColors[5];
        public static Color Wolf_c = Palette.PlayerColors[6];
        public static Color Snake_c = Palette.PlayerColors[2];
        public static Color Seagull_c = Palette.PlayerColors[1];
        public static Color Monkey_c = Palette.PlayerColors[9];

        //Get roles by ID
        public static bool IsSnoop(byte playerId)
        {
            return Snoop != null ? playerId == Snoop.PlayerId : false;
        }
        public static bool IsChameleon(byte playerId)
        {
            return Chameleon != null ? playerId == Chameleon.PlayerId : false;
        }
        public static bool IsCheetah(byte playerId)
        {
            return Cheetah != null ? playerId == Cheetah.PlayerId : false;
        }
        public static bool IsWolf(byte playerId)
        {
            return Wolf != null ? playerId == Wolf.PlayerId : false;
        }
        public static bool IsSnake(byte playerId)
        {
            return Snake != null ? playerId == Snake.PlayerId : false;
        }
        public static bool IsSeagull(byte playerId)
        {
            return Seagull != null ? playerId == Seagull.PlayerId : false;
        }
        public static bool IsMonkey(byte playerId)
        {
            return Monkey != null ? playerId == Monkey.PlayerId : false;
        }

        //Ghost variables
        public static bool isInvisible = false;

        //Captain variables
        public static bool hasVoteAgain = false;

        //Wolf variable
        public static string WolfBaseName;
        public static uint WolfBaseSkin;
        public static uint WolfBasePet;
        public static uint WolfBaseHat;
        public static int WolfBaseColor;

        //Seagull variable
        public static PlayerControl target;

        //Cheetah variable
        public static float baseSpeed;

    }
}
