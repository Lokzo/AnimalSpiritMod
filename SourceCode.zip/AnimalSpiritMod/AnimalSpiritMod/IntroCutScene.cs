﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Hazel;
using UnhollowerBaseLib;
using UnityEngine;
using System.Linq;
using Reactor;
using Reactor.OxygenFilter;
using Reactor.Extensions;
using Reactor.Unstrip;

namespace AnimalSpiritMod
{
	/*[HarmonyPatch(typeof(IntroCutscene._CoBegin_d__11), nameof(IntroCutscene._CoBegin_d__11.MoveNext))]
	public static class IntroCutScenePatch
	{
		public static void Postfix(IntroCutscene._CoBegin_d__11 __instance)
		{
			byte localPlayerId = PlayerControl.LocalPlayer.PlayerId;

			if (Variables.IsSnoop(localPlayerId))
			{
				__instance.__4__this.Title.text = "Mole";
				__instance.__4__this.Title.color = Variables.Snoop_c;
			}
			if (Variables.IsChameleon(localPlayerId))
			{
				__instance.__4__this.Title.text = "Chameleon";
				__instance.__4__this.Title.color = Variables.Chameleon_c;
			}
			if (Variables.IsCheetah(localPlayerId))
			{
				__instance.__4__this.Title.text = "Cheetah";
				__instance.__4__this.Title.color = Variables.Cheetah_c;
			}
			if (Variables.IsHacker(localPlayerId))
			{
				__instance.__4__this.Title.text = "Wolf";
				__instance.__4__this.Title.color = Variables.Hacker_c;
			}
			if (Variables.IsSnake(localPlayerId))
			{
				__instance.__4__this.Title.text = "Snake";
				__instance.__4__this.Title.color = Variables.Snake_c;
			}
			if (Variables.IsSeagull(localPlayerId))
			{
				__instance.__4__this.Title.text = "Seagull";
				__instance.__4__this.Title.color = Variables.Seagull_c;
			}
			if (Variables.IsMonkey(localPlayerId))
			{
				__instance.__4__this.Title.text = "Monkey";
				__instance.__4__this.Title.color = Variables.Monkey_c;
			}

		}
	}*/



}
