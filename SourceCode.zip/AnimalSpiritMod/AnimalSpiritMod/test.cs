﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using Hazel;
using UnhollowerBaseLib;
using UnityEngine;
using TMPro;
using System.Linq;
using Reactor;
using Reactor.OxygenFilter;


namespace AnimalSpiritMod
{
	[HarmonyPatch(typeof(VersionShower), "Start")]
	public static class VersionShowerPatch
	{
		public static void Postfix(VersionShower __instance)
		{
			__instance.text.color = new Color(1f, 0f, 1f, 1f);  
			__instance.text.text += "  Animal Spirit Mod / version: 1.0.0";
		}
	}
}
