﻿using System;
using System.Collections.Generic;
using System.Text;
using Reactor;
using Reactor.OxygenFilter;

namespace AnimalSpiritMod
{
	internal enum RPC
	{
		PlayAnimation,
		CompleteTask,
		SyncSettings,
		SetInfected,
		Exiled,
		CheckName,
		SetName,
		CheckColor,
		SetColor,
		SetHat,
		SetSkin,
		ReportDeadBody,
		MurderPlayer,
		SendChat,
		StartMeeting,
		SetScanner,
		SendChatNote,
		SetPet,
		SetStartCounter,
		EnterVent,
		ExitVent,
		SnapTo,
		Close,
		VotingComplete,
		CastVote,
		ClearVote,
		AddVote,
		CloseDoorsOfType,
		RepairSystem,
		SetTasks,
		UpdateGameData
	}

	internal enum CustomRPC
	{
		SetSnoop = 40,
		SetGhost = 41,
		SetCaptain = 42,
		SetHacker = 43,
		Invisible = 44,
		SetVarInvisibleTrue = 45,
		SetVarInvisibleFalse = 46,
		WolfSkill = 47,
		WolfSkillReset = 48,
		SetCustomColor = 49,
		SetSnake = 50,
		SnakeSkill = 51,
		SetSeagull = 52,
		SetMonkey = 53,
	}
}
