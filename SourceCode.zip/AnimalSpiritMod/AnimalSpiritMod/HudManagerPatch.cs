﻿using HarmonyLib;
using System;
using System.IO;
using System.Net.Http;
using UnityEngine;
using Reactor.Extensions;
using System.Collections.Generic;
using System.Linq;
using Hazel;

namespace AnimalSpiritMod
{
    [HarmonyPatch(typeof(HudManager), nameof(HudManager.Update))]
    class HudManagerUpdatePatch
    {
        public static void Postfix(HudManager __instance)
        {
			PlayerControl player = PlayerControl.LocalPlayer;
			
			//if (AmongUsClient.Instance.GameState != InnerNetClient.GameStates.Started) return;
			CooldownButton.HudUpdate();

			
			byte localPlayerId = player.PlayerId;

			if (Variables.IsSnoop(localPlayerId))
			{
				player.nameText.text = "Snoop\n" + player.name;
				player.nameText.color = Variables.Snoop_c;
			}
			if (Variables.IsChameleon(localPlayerId))
			{
				player.nameText.text = "Chameleon\n" + player.name;
				player.nameText.color = Variables.Chameleon_c;
			}
			if (Variables.IsCheetah(localPlayerId))
			{
				player.nameText.text = "Cheetah\n" + player.name;
				player.nameText.color = Variables.Cheetah_c;
			}
			if (Variables.IsWolf(localPlayerId))
			{
				player.nameText.text = "Wolf\n" + player.name;
				player.nameText.color = Variables.Wolf_c;
			}
			if (Variables.IsSnake(localPlayerId))
			{
				player.nameText.text = "Snake\n" + player.name;
				player.nameText.color = Variables.Snake_c;
			}
			if (Variables.IsSeagull(localPlayerId))
			{
				player.nameText.text = "Seagull\n" + player.name;
				player.nameText.color = Variables.Seagull_c;
				Camera.main.transform.position = Variables.target.transform.position;
			}
			if(Variables.IsMonkey(localPlayerId))
            {
				foreach(PlayerControl p in PlayerControl.AllPlayerControls)
                {
					if (Variables.IsSnoop(p.PlayerId))
					{
						player.nameText.text = "Snoop\n" + player.name;
						p.nameText.color = Variables.Snoop_c;
					}
					if (Variables.IsChameleon(p.PlayerId))
					{
						player.nameText.text = "Chameleon\n" + player.name;
						p.nameText.color = Variables.Chameleon_c;
					}
					if (Variables.IsCheetah(p.PlayerId))
					{
						player.nameText.text = "Cheetah\n" + player.name;
						p.nameText.color = Variables.Cheetah_c;
					}
					if (Variables.IsWolf(p.PlayerId))
					{
						player.nameText.text = "Wolf\n" + player.name;
						p.nameText.color = Variables.Wolf_c;
					}
					if (Variables.IsSnake(p.PlayerId))
					{
						player.nameText.text = "Snake\n" + player.name;
						p.nameText.color = Variables.Snake_c;
					}
					if (Variables.IsSeagull(p.PlayerId))
					{
						player.nameText.text = "Seagull\n" + player.name;
						p.nameText.color = Variables.Seagull_c;
					}
					if (Variables.IsMonkey(p.PlayerId))
					{
						player.nameText.text = "Monkey\n" + player.name;
						p.nameText.color = Variables.Monkey_c;
					}
				}
			}

			if (!Variables.IsChameleon(localPlayerId))
			{
				MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.Invisible, SendOption.None, -1);
				messageWriter.Write(localPlayerId);
				AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
			}
			

		}
		
	}
	/*[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.Start))]
	class PCStartPatch
	{
		public static void Postfix()
		{
			PlayerControl player = PlayerControl.LocalPlayer;
			if (player.Data.PlayerName == "xxlarlivxx")
			{
				player.RpcSetName("Arli");
				SetCustomColor(player);
				MessageWriter messageWriter = AmongUsClient.Instance.StartRpcImmediately(player.NetId, (byte)CustomRPC.SetCustomColor, SendOption.None, -1);
				messageWriter.Write(player.PlayerId);
				AmongUsClient.Instance.FinishRpcImmediately(messageWriter);
			}
		}
		public static void SetCustomColor(PlayerControl player)
		{
			Color grey = new Color(0.5f, 0.5f, 0.5f, 1f);
			Color red = new Color(1f, 0f, 0f, 0.5f);
			player.myRend.material.SetColor("_BackColor", grey);
			player.myRend.material.SetColor("_BodyColor", grey);
			player.myRend.material.SetColor("_VisorColor", red);
		}
	}*/
}





