﻿using System;
using System.Text;
using UnityEngine;
using Il2CppSystem.Collections.Generic;

namespace AnimalSpiritMod
{
    public class WolfSkill
    {
        public static PlayerControl getClosestPlayer(PlayerControl player)
        {
            PlayerControl target = null;
			float num = GameOptionsData.KillDistances[Mathf.Clamp(PlayerControl.GameOptions.KillDistance, 0, 2)];
			if (!ShipStatus.Instance)
			{
				return null;
			}
			Vector2 truePosition = player.GetTruePosition();
			List<GameData.PlayerInfo> allPlayers = GameData.Instance.AllPlayers;
			for (int i = 0; i < allPlayers.Count; i++)
			{
				GameData.PlayerInfo playerInfo = allPlayers[i];
				if (!playerInfo.Disconnected && playerInfo.PlayerId != player.PlayerId && !playerInfo.IsDead)
				{
					PlayerControl @object = playerInfo.Object;
					if (@object)
					{
						Vector2 vector = @object.GetTruePosition() - truePosition;
						float magnitude = vector.magnitude;
						if (magnitude <= num && !PhysicsHelpers.AnyNonTriggersBetween(truePosition, vector.normalized, magnitude, Constants.ShipAndObjectsMask))
						{
							target = @object;
							num = magnitude;
						}
					}
				}
			}

			return target;
        }
    }
}
